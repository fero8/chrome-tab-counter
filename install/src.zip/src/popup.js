window.addEventListener("load", initPopup);
